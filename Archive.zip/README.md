# mindscope
